module hazard_detection_unit(input logic has_Rn, has_Rm, input logic [4:0] Rn, Rm, input logic [4:0] ID_EX_regRd, input logic ID_EX_MemRead, output logic stall);
	always_comb begin
	   // Es medio que un lio pero basicamente se aplica la condicion de deteccion de Hazard, pagina 324:
		//		if (ID/EX.MemRead and
		//			((ID/EX.RegisterRd = IF/ID.RegisterRn1) or
		//				(ID/EX.RegisterRd = IF/ID.RegisterRm2)))
		//				stall the pipeline
	   if(has_Rn) begin
			if(has_Rm) begin
				stall = ID_EX_MemRead && ((ID_EX_regRd == Rn) || (ID_EX_regRd == Rm)); // RD contra RN y RD contra RM
			end
			else begin
				stall = ID_EX_MemRead && ID_EX_regRd == Rn; // RD contra RN
			end
		end
		else begin
			if(has_Rm) begin
				stall = ID_EX_MemRead && ID_EX_regRd == Rm; // RD contra RM
			end
			else begin
				stall = 'b0;
			end
		end
	end
endmodule 