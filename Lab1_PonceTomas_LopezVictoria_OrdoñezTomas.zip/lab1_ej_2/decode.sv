// Etapa: DECODE

module decode #(parameter N = 64)
					(input logic regWrite_D, reg2loc_D, clk,
					input logic [N-1:0] writeData3_D,
					input logic [31:0] instr_D,
					output logic [N-1:0] signImm_D, readData1_D, readData2_D, 
					input logic [4:0] wa3_D, // Eliminar para single cycle processor
					input logic ID_EX_MemRead, // Eliminar para single cycle processor
					input logic [4:0] ID_EX_regRd, // Eliminar para single cycle processor
					output logic has_Rd, has_Rn, has_Rm, output logic [4:0] Rd, Rn, Rm, // Eliminar para single cycle processor
					output logic stall); // Eliminar para single cycle processor
	
	logic [4:0] ra2;			
	mux2 	#(5) 	ra2mux	(.d0(instr_D[20:16]), .d1(instr_D[4:0]), .s(reg2loc_D), .y(ra2));
	
	regfile 		registers(.clk(clk), .we3(regWrite_D), .ra1(instr_D[9:5]), .ra2(ra2), .wa3(wa3_D), 
								 .wd3(writeData3_D), .rd1(readData1_D), .rd2(readData2_D));
								
	// En single cycle processor:						
	//regfile registers (.clk(clk), .we3(regWrite_D), .ra1(instr_D[9:5]), .ra2(ra2), .wa3(instr_D[4:0]), 
	//							 .wd3(writeData3_D), .rd1(readData1_D), .rd2(readData2_D));
	
									
	signext 		ext		(.a(instr_D), .y(signImm_D));
	
	// Instruction Register Decoder
	// Basicamente vemos si la instruccion tiene Rd, Rn o Rm y obtenemos sus valores
	instruction_register_decoder IRD(.instruction(instr_D), .has_Rd(has_Rd), .has_Rn(has_Rn), .has_Rm(has_Rm), .Rd(Rd),  .Rn(Rn), .Rm(Rm));
	
	// Hazard Detection Unit para determinar si hacer stall o no.
	hazard_detection_unit HDU(.has_Rn(has_Rn), .has_Rm(has_Rm),  .Rn(Rn), .Rm(Rm), .ID_EX_regRd(ID_EX_regRd), .ID_EX_MemRead(ID_EX_MemRead), .stall(stall));
endmodule
