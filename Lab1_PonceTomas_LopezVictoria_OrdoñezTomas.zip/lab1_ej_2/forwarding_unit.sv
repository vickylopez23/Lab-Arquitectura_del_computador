
module forwarding_unit (input logic [4:0] ID_EX_RegRn1, ID_EX_RegRm2, EX_MEM_RegRd, MEM_WB_RegRd, input logic EX_MEM_RegWrite, MEM_WB_RegWrite, output logic [1:0] ForwardA, ForwardB);
	
  // Utilizamos las guardas provistas por el libro para hacer forwarding

  always_comb begin
    if (EX_MEM_RegWrite && (EX_MEM_RegRd != 31) && (EX_MEM_RegRd == ID_EX_RegRn1)) // Aca vemos de hacer forward desde EX_MEM a Execute para el primer operando
      ForwardA = 'b10;
    else if (MEM_WB_RegWrite && MEM_WB_RegRd != 31 && MEM_WB_RegRd == ID_EX_RegRn1) // Aca vemos de hacer forward desde MEM_WB a Execute para el primer operando
      ForwardA = 'b01;
    else // No hacemos forwarding para el primer operando
      ForwardA = 'b00;
		
    if (EX_MEM_RegWrite && EX_MEM_RegRd != 31 && EX_MEM_RegRd == ID_EX_RegRm2) // Aca vemos de hacer forward desde EX_MEM a Execute para el segundo operando
      ForwardB = 'b10;
    else if (MEM_WB_RegWrite && MEM_WB_RegRd != 31 && MEM_WB_RegRd == ID_EX_RegRm2) // Aca vemos de hacer forward desde MEM_WB a Execute para el segundo operando
      ForwardB = 'b01;
    else
      ForwardB = 'b00; // No hacemos forwarding para el segundo operando
  end
  
endmodule