transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/writeback.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/sl2.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/signext.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/regfile.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/processor_arm.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/mux2.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/memory.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/maindec.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/flopr.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/fetch.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/execute.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/decode.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/datapath.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/controller.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/aludec.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/alu.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/adder.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/flopre.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/hazard_detection_unit.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/instruction_register_decoder.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/forwarding_unit.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/imem.sv}
vcom -2008 -work work {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/dmem.vhd}

vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_2/processor_tb.sv}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  processor_tb

add wave *
view structure
view signals
run -all
