module fetch #(parameter N = 64) (input logic PCSrc_F, clk, reset, stall, input logic [N-1:0] PCBranch_F, output logic [N-1:0] imem_addr_F);
	
	
	logic [N-1:0] PC_in;
	logic [N-1:0] adder_out;
	
	mux2 #(N) mux2(adder_out, PCBranch_F, PCSrc_F, PC_in);
	flopre #(N) PC(clk, reset, !stall, PC_in, imem_addr_F);
	adder #(N) adder(imem_addr_F, N'('d4), adder_out);
endmodule