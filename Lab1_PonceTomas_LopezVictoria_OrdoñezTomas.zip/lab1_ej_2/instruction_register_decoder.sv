module instruction_register_decoder(input logic [31:0] instruction, output logic has_Rd, has_Rn, has_Rm, output logic [4:0] Rd, Rn, Rm);
	always_comb begin
		casez(instruction[31:21])
			'b111_1100_0010: begin // LDUR, TIPO D
				has_Rd = 1;
				has_Rn = 1;
				has_Rm = 0;
				Rd = instruction[4:0];
				Rn = instruction[9:5];
				Rm = 5'b11111;
			end
			'b111_1100_0000: begin // STUR, TIPO D
				has_Rd = 0;
				has_Rn = 1;
				has_Rm = 1;
				Rd = 5'b11111;
				Rn = instruction[9:5];
				Rm = instruction[4:0];
			end
			'b101_1010_0???: begin // CBZ // TIPO CB
				has_Rd = 0;
				has_Rn = 0;
				has_Rm = 1;
				Rd = 5'b11111;
				Rn = 5'b11111;
				Rm = instruction[4:0];
			end
			'b110_1001_01??: begin // MOVZ // IM
				has_Rd = 1;
				has_Rn = 0;
				has_Rm = 0;
				Rd = instruction[4:0];
				Rn = 5'b11111;
				Rm = 5'b11111;
			end
			'b100_0101_1000,
			'b110_0101_1000,
			'b100_0101_0000,
			'b101_0101_0000: begin // ADD, SUB, AND, ORR // TIPO R
				has_Rd = 1;
				has_Rn = 1;
				has_Rm = 1;
				Rd = instruction[4:0];
				Rn = instruction[9:5];
				Rm = instruction[20:16];
			end
			default: begin
			   has_Rd = 0;
				has_Rn = 0;
				has_Rm = 0;
				Rd = 5'b11111;
				Rn = 5'b11111;
				Rm = 5'b11111;
			end
		endcase
	end
endmodule 