module execute #(parameter N = 64)(input logic AluSrc, input logic [3:0] AluControl, input logic [N-1:0] PC_E, signImm_E, readData1_E, readData2_E,
               input logic [1:0] fu_ForwardA, fu_ForwardB,
					input logic [N-1:0] EX_MEM_Forward_Data, WB_Forward_Data,
					output logic [N-1:0] PCBranch_E, aluResult_E, writeData_E, output logic zero_E);

	logic [N-1:0] ReadData2_AfterForward;
	logic [N-1:0] ALUOperandA, ALUOperandB;
	
	logic [N-1:0] sl2_out;
	sl2 #(N) sl2(signImm_E, sl2_out);
	
	adder #(N) adder(PC_E, sl2_out, PCBranch_E);
	mux2 #(N) mux2(ReadData2_AfterForward, signImm_E, AluSrc, ALUOperandB);
	
	always_comb begin
		casez(fu_ForwardA)
			2'b01: // Forward desde WB (Memory o Resultado de la ALU previo)
			  ALUOperandA = WB_Forward_Data;
			2'b10: // Forward desde EX_MEM (Resultado de la ALU)
			  ALUOperandA = EX_MEM_Forward_Data;
			default: ALUOperandA = readData1_E;
		endcase
		casez(fu_ForwardB)
			2'b01: // Forward desde WB (Memory o Resultado de la ALU previo)
			  ReadData2_AfterForward = WB_Forward_Data;
			2'b10: // Forward desde EX_MEM (Resultado de la ALU)
			  ReadData2_AfterForward = EX_MEM_Forward_Data;
			default: ReadData2_AfterForward = readData2_E;
		endcase
	end
	alu alu(ALUOperandA, ALUOperandB, AluControl, aluResult_E, zero_E);
	
	assign writeData_E = ReadData2_AfterForward;
	
endmodule