module flopre #(parameter N = 64) (
		input logic clk, input logic reset, enabled, input logic [N-1:0] d,
		output logic [N-1:0] q
	);

	always_ff @(posedge clk, posedge reset)
	   // CHECK, reset deberia de funcionar con enable deshabilitado o no?
		if (reset) q <= '0;
		else begin
			if (enabled) begin
				q <= d;
			end
		end

endmodule