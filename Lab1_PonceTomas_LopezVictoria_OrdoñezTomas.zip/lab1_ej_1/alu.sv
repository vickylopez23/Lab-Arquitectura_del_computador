module alu(input logic [63:0] a, input logic [63:0] b, input logic [3:0] ALUControl,
		output logic [63:0] result, output logic zero);
		always_comb begin
			casez(ALUControl)
				4'b0000: 
					result = a & b;
				4'b0001:
					result = a | b;
				4'b0010:
					result = a + b;
				4'b0110:
					result = a - b;
				4'b0111:
					result = b;
				4'b1000: // Colocamos 0 excepto en la seccion 0 (MOVZ)
					result = {{48'b0}, b[15:0]};
				4'b1001: // Colocamos 0 excepto en la seccion 1 (MOVZ)
					result = {{32'b0}, b[15:0], {16'b0}};
				4'b1010: // Colocamos 0 excepto en la seccion 2 (MOVZ)
					result = {{16'b0}, b[15:0], {32'b0}};	
				4'b1011: // Colocamos 0 excepto en la seccion 3 (MOVZ)
					result = {b[15:0], {48'b0}};
				default: result = '1;
			endcase
			zero = result == '0 ? '1 : '0;
		end
endmodule