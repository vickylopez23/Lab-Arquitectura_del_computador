transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/writeback.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/sl2.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/signext.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/regfile.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/processor_arm.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/mux2.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/memory.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/maindec.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/flopr.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/fetch.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/execute.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/decode.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/datapath.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/controller.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/aludec.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/alu.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/adder.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/imem.sv}
vcom -2008 -work work {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/dmem.vhd}

vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_1/processor_tb.sv}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  processor_tb

add wave *
view structure
view signals
run -all
