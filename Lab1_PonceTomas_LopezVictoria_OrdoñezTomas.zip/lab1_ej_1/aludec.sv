// ALU CONTROL DECODER

module aludec (input  logic [10:0] funct,  
					input  logic [1:0]  aluop,  
					output logic [3:0] alucontrol);  				
						
	always_comb
		if (aluop == 2'b00) alucontrol = 4'b0010;			// LDUR or STUR		
		else if (aluop == 2'b01) alucontrol = 4'b0111; 	//CBZ
		else if((aluop == 2'b10)  & (funct == 11'b10001011000)) alucontrol = 4'b0010;	//ADD
		else if((aluop == 2'b10)  & (funct == 11'b11001011000)) alucontrol = 4'b0110;	//SUB
		else if((aluop == 2'b10)  & (funct == 11'b10001010000)) alucontrol = 4'b0000;	//AND
		else if((aluop == 2'b10)  & (funct == 11'b10101010000)) alucontrol = 4'b0001;	//OR 
		else if((aluop == 2'b11)  & (funct == 11'b110_1001_01_00)) alucontrol = 4'b1000; // MOVZ LSL 00 #0
		else if((aluop == 2'b11)  & (funct == 11'b110_1001_01_01)) alucontrol = 4'b1001; // MOVZ LSL 01 #16
		else if((aluop == 2'b11)  & (funct == 11'b110_1001_01_10)) alucontrol = 4'b1010; // MOVZ LSL 10 #32
		else if((aluop == 2'b11)  & (funct == 11'b110_1001_01_11)) alucontrol = 4'b1011; // MOVZ LSL 11 #48
		else alucontrol = 4'b0000;
endmodule
