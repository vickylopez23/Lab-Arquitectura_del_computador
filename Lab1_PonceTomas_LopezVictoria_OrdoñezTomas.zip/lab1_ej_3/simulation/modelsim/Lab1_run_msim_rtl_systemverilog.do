transcript on
if {[file exists rtl_work]} {
	vdel -lib rtl_work -all
}
vlib rtl_work
vmap work rtl_work

vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/writeback.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/sl2.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/signext.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/regfile.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/processor_arm.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/mux2.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/memory.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/maindec.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/flopr.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/fetch.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/execute.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/decode.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/datapath.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/controller.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/aludec.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/alu.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/adder.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/flopre.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/hazard_detection_unit.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/instruction_register_decoder.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/forwarding_unit.sv}
vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/imem.sv}
vcom -2008 -work work {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/dmem.vhd}

vlog -sv -work work +incdir+/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3 {/home/wdazsh/Documents/LabsArquiComp/lab1_ej_3/processor_tb.sv}

vsim -t 1ps -L altera_ver -L lpm_ver -L sgate_ver -L altera_mf_ver -L altera_lnsim_ver -L cycloneive_ver -L rtl_work -L work -voptargs="+acc"  processor_tb

add wave *
view structure
view signals
run -all
